import { skillIcon, type CustomCommand, type Skill } from '@/features/skills/skills-data'
import {
  BarChart3,
  CircleHelp,
  Command,
  NotebookText,
  Puzzle,
  ClipboardList,
  Cpu,
  Layers,
  Minimize2,
  type LucideIcon
} from 'lucide-react'

export type PanelId =
  | 'model'
  | 'context'
  | 'help'
  | 'usage'
  | 'skills'
  | 'commands'
export type ActionId = 'compact'
export type CommandGroup =
  | 'Conversation'
  | 'Skills'
  | 'Your commands'
  | 'Workspace'
  | 'Insights'
  | 'Utilities'
  | 'Shortcuts'

export type SlashCommand = {
  id: string
  description: string
  icon: LucideIcon
  group: CommandGroup
  /** Hint shown after the name when the command takes extra text, e.g. "[what to focus on]". */
  hint?: string
  /** Small tag on the right, e.g. "new". */
  badge?: string
} & (
  | { kind: 'panel'; panel: PanelId }
  | { kind: 'action'; action: ActionId }
  | { kind: 'prompt'; prompt: string }
  | { kind: 'prefill'; text: string }
  | { kind: 'skill'; skill: Skill }
  | { kind: 'custom'; command: CustomCommand }
)

/** Add a command here and it appears in the "/" menu. Panels render in panels/. */
export const BUILT_IN_COMMANDS: SlashCommand[] = [
  {
    id: 'plan',
    description: 'Add an editable planning prompt to the message box',
    icon: ClipboardList,
    group: 'Conversation',
    hint: '[add your task]',
    kind: 'prefill',
    text: 'Make a plan for '
  },
  {
    id: 'compact',
    description: 'Summarize this chat to free context',
    icon: Minimize2,
    group: 'Utilities',
    kind: 'action',
    action: 'compact'
  },
  {
    id: 'skills',
    description: 'Browse and manage skills',
    icon: Puzzle,
    group: 'Skills',
    kind: 'panel',
    panel: 'skills',
    badge: 'new'
  },
  {
    id: 'commands',
    description: 'Create or edit your commands',
    icon: Command,
    group: 'Your commands',
    kind: 'panel',
    panel: 'commands'
  },
  {
    id: 'model',
    description: 'Choose a model',
    icon: Cpu,
    group: 'Workspace',
    kind: 'panel',
    panel: 'model'
  },
  {
    id: 'context',
    description: 'See what is using context',
    icon: Layers,
    group: 'Insights',
    kind: 'panel',
    panel: 'context'
  },
  {
    id: 'usage',
    description: 'Daily messages and token use',
    icon: BarChart3,
    group: 'Insights',
    kind: 'panel',
    panel: 'usage'
  },
  {
    id: 'help',
    description: 'Slash commands and keyboard shortcuts',
    icon: CircleHelp,
    group: 'Shortcuts',
    kind: 'panel',
    panel: 'help'
  }
]

export const SLASH_COMMANDS = BUILT_IN_COMMANDS

export const GROUP_ORDER: CommandGroup[] = [
  'Conversation',
  'Skills',
  'Your commands',
  'Workspace',
  'Utilities',
  'Insights',
  'Shortcuts'
]

/** Built-in commands plus the skills that are switched on and the person's own commands. */
export function buildCommands(skills: Skill[], custom: CustomCommand[]): SlashCommand[] {
  return [
    ...BUILT_IN_COMMANDS,
    ...skills.map(
      (skill): SlashCommand => ({
        id: skill.id,
        description: skill.description,
        icon: skillIcon(skill.icon),
        group: 'Skills',
        hint: '[what to use it on]',
        kind: 'skill',
        skill
      })
    ),
    ...custom.map(
      (command): SlashCommand => ({
        id: command.id,
        description: command.description || 'Your command',
        icon: NotebookText,
        group: 'Your commands',
        hint: command.prompt.includes('$ARGUMENTS') ? '[text]' : undefined,
        kind: 'custom',
        command
      })
    )
  ]
}

const grouped = (list: SlashCommand[]): SlashCommand[] =>
  GROUP_ORDER.flatMap((g) => list.filter((c) => c.group === g))

/** Commands that start with the query first, then ones that only contain it. */
export function filterCommands(list: SlashCommand[], query: string): SlashCommand[] {
  const q = query.toLowerCase()
  if (!q) return grouped(list) // grouped order, so the keyboard index matches what is drawn
  const starts = list.filter((c) => c.id.startsWith(q))
  const rest = list.filter(
    (c) => !c.id.startsWith(q) && (c.id.includes(q) || c.description.toLowerCase().includes(q))
  )
  return [...starts, ...rest]
}

/** "/code-review src/app.ts" → the command and what was typed after it. */
export function parseSlash(
  list: SlashCommand[],
  text: string
): { command: SlashCommand; args: string } | null {
  const m = /^\/([a-z0-9-]+)(?:\s+([\s\S]*))?$/.exec(text.trim())
  if (!m) return null
  const command = list.find((c) => c.id === m[1])
  return command ? { command, args: m[2] ?? '' } : null
}
