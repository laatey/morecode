export interface ModelInfo {
  /** The model name sent to the API. */
  id: string
  name: string
  description: string
}

export const KAGGLE_QWEN_MODEL = 'qwen2.5-coder-14b-kaggle'
export const MORLINE_GATEWAY_MODEL = 'anthropic/claude-sonnet-5'
export const OPENROUTER_FREE_MODEL = 'openrouter/free'

export const MODELS: ModelInfo[] = [
  { id: 'claude-opus-5-5', name: 'Opus 5.5', description: 'Most capable, for complex work' },
  { id: 'claude-sonnet-5-5', name: 'Sonnet 5.5', description: 'Balanced speed and quality' },
  { id: 'claude-haiku-5-5', name: 'Haiku 5.5', description: 'Fastest, for quick edits' },
  {
    id: MORLINE_GATEWAY_MODEL,
    name: 'Claude Sonnet (Gateway)',
    description: 'Your separately deployed AI gateway service'
  },
  {
    id: KAGGLE_QWEN_MODEL,
    name: 'Qwen Coder 14B (Kaggle)',
    description: 'Your temporary private Kaggle notebook endpoint'
  },
  {
    id: OPENROUTER_FREE_MODEL,
    name: 'OpenRouter Free',
    description: 'Free community models, best for personal testing'
  }
]

export const DEFAULT_MODEL = 'claude-sonnet-5-5'

/** A saved model name that no longer exists (from an older version) falls back to the default. */
export const resolveModel = (id: string): string =>
  MODELS.some((m) => m.id === id) ? id : DEFAULT_MODEL

export const modelName = (id: string): string => MODELS.find((m) => m.id === id)?.name ?? id

export const isKaggleQwen = (id: string): boolean => id === KAGGLE_QWEN_MODEL
export const isMorlineGateway = (id: string): boolean => id === MORLINE_GATEWAY_MODEL
export const isOpenRouterFree = (id: string): boolean => id === OPENROUTER_FREE_MODEL
